"""
Subscription management system for the trading bot
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from utils.timezone_handler import TimezoneHandler

class SubscriptionManager:
    """Manages user subscriptions and payment verification"""
    
    def __init__(self):
        self.timezone_handler = TimezoneHandler()
        self.subscriptions_file = "subscriptions.json"
        self.payment_methods = {
            "bank_transfer": {
                "name": "Bank Transfer",
                "details": "Account Name: Trading Bot Services\nBank: Access Bank\nAccount Number: 1234567890\nAmount: ₦5,000"
            },
            "mobile_money": {
                "name": "Mobile Money",
                "details": "Send ₦5,000 to:\nPhone: +234 123 456 7890\nName: Trading Bot Services"
            }
        }
        self.subscription_price = 5000  # Nigerian Naira
        self.free_slots = 3
        self.subscription_duration_days = 30
        
        # Load existing subscriptions
        self.subscriptions = self._load_subscriptions()
    
    def _load_subscriptions(self) -> Dict:
        """Load subscriptions from file"""
        if os.path.exists(self.subscriptions_file):
            try:
                with open(self.subscriptions_file, 'r') as f:
                    data = json.load(f)
                    # Convert string dates back to datetime objects
                    for user_id, sub_data in data.items():
                        if 'expiry_date' in sub_data:
                            sub_data['expiry_date'] = datetime.fromisoformat(sub_data['expiry_date'])
                        if 'registration_date' in sub_data:
                            sub_data['registration_date'] = datetime.fromisoformat(sub_data['registration_date'])
                    return data
            except (json.JSONDecodeError, ValueError):
                return {}
        return {}
    
    def _save_subscriptions(self):
        """Save subscriptions to file"""
        # Convert datetime objects to strings for JSON serialization
        data_to_save = {}
        for user_id, sub_data in self.subscriptions.items():
            data_copy = sub_data.copy()
            if 'expiry_date' in data_copy:
                data_copy['expiry_date'] = data_copy['expiry_date'].isoformat()
            if 'registration_date' in data_copy:
                data_copy['registration_date'] = data_copy['registration_date'].isoformat()
            data_to_save[user_id] = data_copy
        
        with open(self.subscriptions_file, 'w') as f:
            json.dump(data_to_save, f, indent=2)
    
    def check_user_access(self, user_id: int) -> Tuple[bool, str]:
        """Check if user has access to the bot"""
        user_id_str = str(user_id)
        
        # Check if user is already subscribed
        if user_id_str in self.subscriptions:
            subscription = self.subscriptions[user_id_str]
            
            # Check if subscription is still valid
            if subscription.get('expiry_date'):
                if datetime.now() < subscription['expiry_date']:
                    days_left = (subscription['expiry_date'] - datetime.now()).days
                    return True, f"Active subscription ({days_left} days remaining)"
                else:
                    return False, "Subscription expired"
            
            # Check if user has free access
            if subscription.get('is_free', False):
                return True, "Free access"
        
        # Check if free slots are available
        free_users = [sub for sub in self.subscriptions.values() if sub.get('is_free', False)]
        if len(free_users) < self.free_slots:
            return True, "Free slot available"
        
        return False, "Payment required"
    
    def register_free_user(self, user_id: int, username: str = None) -> bool:
        """Register a user for free access"""
        free_users = [sub for sub in self.subscriptions.values() if sub.get('is_free', False)]
        
        if len(free_users) >= self.free_slots:
            return False
        
        user_id_str = str(user_id)
        self.subscriptions[user_id_str] = {
            'user_id': user_id,
            'username': username,
            'is_free': True,
            'registration_date': datetime.now(),
            'status': 'active'
        }
        
        self._save_subscriptions()
        return True
    
    def get_payment_info(self) -> str:
        """Get payment information message"""
        free_users = [sub for sub in self.subscriptions.values() if sub.get('is_free', False)]
        free_slots_left = self.free_slots - len(free_users)
        
        if free_slots_left > 0:
            return f"🎉 Good news! You get FREE access (only {free_slots_left} free slots left)!"
        
        payment_info = f"""💳 **Subscription Payment Required**

📋 **Subscription Details:**
• Price: ₦{self.subscription_price:,} Nigerian Naira
• Duration: {self.subscription_duration_days} days
• Access: Unlimited trading signals

🏦 **Payment Methods:**

**1. Bank Transfer**
{self.payment_methods['bank_transfer']['details']}

**2. Mobile Money**
{self.payment_methods['mobile_money']['details']}

📝 **Payment Instructions:**
1. Make payment using any method above
2. Send payment screenshot to admin
3. Include your Telegram username in payment reference
4. Wait for verification (usually within 1 hour)

⚠️ **Important Notes:**
• Payment is one-time for {self.subscription_duration_days} days access
• First 3 users get free access (slots filled)
• Keep payment receipt for verification
• Contact admin if payment issues occur

Once payment is verified, you'll get immediate access to premium trading signals!"""
        
        return payment_info
    
    def verify_payment(self, user_id: int, username: str = None, admin_user_id: int = None) -> bool:
        """Verify payment and activate subscription (admin only)"""
        from config.settings import ADMIN_USER_IDS
        if admin_user_id and admin_user_id not in ADMIN_USER_IDS:
            return False
        
        user_id_str = str(user_id)
        current_time = datetime.now()
        expiry_date = current_time + timedelta(days=self.subscription_duration_days)
        
        self.subscriptions[user_id_str] = {
            'user_id': user_id,
            'username': username,
            'is_free': False,
            'registration_date': current_time,
            'expiry_date': expiry_date,
            'status': 'active',
            'payment_verified': True
        }
        
        self._save_subscriptions()
        return True
    
    def get_subscription_status(self, user_id: int) -> Dict:
        """Get detailed subscription status"""
        user_id_str = str(user_id)
        
        if user_id_str not in self.subscriptions:
            return {
                'status': 'not_subscribed',
                'message': 'No subscription found'
            }
        
        subscription = self.subscriptions[user_id_str]
        
        if subscription.get('is_free', False):
            return {
                'status': 'free',
                'message': 'Free access',
                'registration_date': subscription.get('registration_date')
            }
        
        if subscription.get('expiry_date'):
            if datetime.now() < subscription['expiry_date']:
                days_left = (subscription['expiry_date'] - datetime.now()).days
                return {
                    'status': 'active',
                    'message': f'Active subscription ({days_left} days remaining)',
                    'expiry_date': subscription['expiry_date'],
                    'registration_date': subscription.get('registration_date')
                }
            else:
                return {
                    'status': 'expired',
                    'message': 'Subscription expired',
                    'expiry_date': subscription['expiry_date']
                }
        
        return {
            'status': 'pending',
            'message': 'Payment verification pending'
        }
    
    def get_admin_stats(self) -> Dict:
        """Get subscription statistics for admin"""
        total_users = len(self.subscriptions)
        free_users = sum(1 for sub in self.subscriptions.values() if sub.get('is_free', False))
        paid_users = total_users - free_users
        active_paid = sum(1 for sub in self.subscriptions.values() 
                         if not sub.get('is_free', False) and 
                         sub.get('expiry_date') and 
                         datetime.now() < sub['expiry_date'])
        
        return {
            'total_users': total_users,
            'free_users': free_users,
            'paid_users': paid_users,
            'active_paid': active_paid,
            'free_slots_left': self.free_slots - free_users,
            'total_revenue': paid_users * self.subscription_price
        }
    
    def extend_subscription(self, user_id: int, days: int, admin_user_id: int = None) -> bool:
        """Extend user subscription (admin only)"""
        from config.settings import ADMIN_USER_IDS
        if admin_user_id and admin_user_id not in ADMIN_USER_IDS:
            return False
        
        user_id_str = str(user_id)
        if user_id_str not in self.subscriptions:
            return False
        
        subscription = self.subscriptions[user_id_str]
        current_expiry = subscription.get('expiry_date', datetime.now())
        
        if current_expiry < datetime.now():
            # If expired, extend from now
            new_expiry = datetime.now() + timedelta(days=days)
        else:
            # If active, extend from current expiry
            new_expiry = current_expiry + timedelta(days=days)
        
        subscription['expiry_date'] = new_expiry
        subscription['status'] = 'active'
        
        self._save_subscriptions()
        return True